export declare const errorIconMarkup: () => string;
export declare const warningIconMarkup: () => string;
export declare const successIconMarkup: () => string;
